import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, Clock, FileText, Car } from "lucide-react"

export default function ClientDashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-montserrat text-2xl font-bold text-navy-blue md:text-3xl">Tableau de bord</h1>
        <p className="mt-1 text-gray-500">Bienvenue dans votre espace client</p>
      </div>

      {/* Grille de cartes */}
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        {/* Actions rapides */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Actions rapides</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              <Button className="justify-start" asChild>
                <Link href="/rendez-vous">
                  <Calendar className="mr-2 h-4 w-4" />
                  Prendre rendez-vous
                </Link>
              </Button>
              <Button variant="outline" className="justify-start" asChild>
                <Link href="/espace-client/vehicules/ajouter">
                  <Car className="mr-2 h-4 w-4" />
                  Ajouter un véhicule
                </Link>
              </Button>
              <Button variant="outline" className="justify-start" asChild>
                <Link href="/contact">
                  <Clock className="mr-2 h-4 w-4" />
                  Contacter le garage
                </Link>
              </Button>
              <Button variant="outline" className="justify-start" asChild>
                <Link href="/espace-client/parametres">
                  <FileText className="mr-2 h-4 w-4" />
                  Gérer mon profil
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
