"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { FileText, Download, Search, Eye } from "lucide-react"

export default function ClientInvoices() {
  const [activeTab, setActiveTab] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")

  // Données fictives pour les factures
  const invoices = {
    all: [
      {
        id: 1,
        reference: "F-2025-042",
        date: "15 février 2025",
        service: "Vidange et filtres",
        amount: "89,00 €",
        status: "unpaid",
        dueDate: "15 mars 2025",
      },
      {
        id: 2,
        reference: "F-2024-156",
        date: "10 novembre 2024",
        service: "Remplacement plaquettes de frein",
        amount: "145,00 €",
        status: "paid",
        paidDate: "15 novembre 2024",
      },
      {
        id: 3,
        reference: "F-2024-089",
        date: "5 juin 2024",
        service: "Révision complète",
        amount: "210,00 €",
        status: "paid",
        paidDate: "10 juin 2024",
      },
    ],
    unpaid: [
      {
        id: 1,
        reference: "F-2025-042",
        date: "15 février 2025",
        service: "Vidange et filtres",
        amount: "89,00 €",
        status: "unpaid",
        dueDate: "15 mars 2025",
      },
    ],
    paid: [
      {
        id: 2,
        reference: "F-2024-156",
        date: "10 novembre 2024",
        service: "Remplacement plaquettes de frein",
        amount: "145,00 €",
        status: "paid",
        paidDate: "15 novembre 2024",
      },
      {
        id: 3,
        reference: "F-2024-089",
        date: "5 juin 2024",
        service: "Révision complète",
        amount: "210,00 €",
        status: "paid",
        paidDate: "10 juin 2024",
      },
    ],
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return <Badge className="bg-green-500">Payée</Badge>
      case "unpaid":
        return (
          <Badge variant="outline" className="border-amber-300 bg-amber-50 text-amber-700">
            À payer
          </Badge>
        )
      default:
        return <Badge className="bg-gray-500">Inconnu</Badge>
    }
  }

  const filteredInvoices = invoices[activeTab as keyof typeof invoices].filter((invoice) => {
    return (
      invoice.reference.toLowerCase().includes(searchQuery.toLowerCase()) ||
      invoice.service.toLowerCase().includes(searchQuery.toLowerCase())
    )
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-montserrat text-2xl font-bold text-navy-blue md:text-3xl">Mes factures</h1>
        <p className="mt-1 text-gray-500">Consultez et téléchargez vos factures</p>
      </div>

      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="flex flex-col space-y-4 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
          <TabsList>
            <TabsTrigger value="all">Toutes</TabsTrigger>
            <TabsTrigger value="unpaid">À payer</TabsTrigger>
            <TabsTrigger value="paid">Payées</TabsTrigger>
          </TabsList>
          <div className="flex w-full items-center sm:w-auto sm:max-w-xs">
            <Search className="mr-2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Rechercher..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full"
            />
          </div>
        </div>

        <TabsContent value="all" className="mt-6">
          <InvoiceTable invoices={filteredInvoices} getStatusBadge={getStatusBadge} />
        </TabsContent>

        <TabsContent value="unpaid" className="mt-6">
          <InvoiceTable invoices={filteredInvoices} getStatusBadge={getStatusBadge} />
        </TabsContent>

        <TabsContent value="paid" className="mt-6">
          <InvoiceTable invoices={filteredInvoices} getStatusBadge={getStatusBadge} />
        </TabsContent>
      </Tabs>
    </div>
  )
}

interface InvoiceTableProps {
  invoices: Array<{
    id: number
    reference: string
    date: string
    service: string
    amount: string
    status: string
    dueDate?: string
    paidDate?: string
  }>
  getStatusBadge: (status: string) => JSX.Element
}

function InvoiceTable({ invoices, getStatusBadge }: InvoiceTableProps) {
  return (
    <>
      {invoices.length > 0 ? (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Référence</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Service</TableHead>
                  <TableHead>Montant</TableHead>
                  <TableHead>Statut</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {invoices.map((invoice) => (
                  <TableRow key={invoice.id}>
                    <TableCell className="font-medium">{invoice.reference}</TableCell>
                    <TableCell>{invoice.date}</TableCell>
                    <TableCell>{invoice.service}</TableCell>
                    <TableCell>{invoice.amount}</TableCell>
                    <TableCell>{getStatusBadge(invoice.status)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/espace-client/factures/${invoice.id}`}>
                            <Eye className="h-4 w-4" />
                            <span className="sr-only">Voir</span>
                          </Link>
                        </Button>
                        <Button variant="ghost" size="icon">
                          <Download className="h-4 w-4" />
                          <span className="sr-only">Télécharger</span>
                        </Button>
                        {invoice.status === "unpaid" && (
                          <Button size="sm" asChild>
                            <Link href={`/espace-client/factures/${invoice.id}/payer`}>Payer</Link>
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-6 text-center">
            <FileText className="h-12 w-12 text-gray-300" />
            <p className="mt-2 text-gray-500">Aucune facture trouvée</p>
          </CardContent>
        </Card>
      )}
    </>
  )
}
