"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { Switch } from "@/components/ui/switch"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, Check } from "lucide-react"

export default function AccountSettings() {
  const [activeTab, setActiveTab] = useState("profile")
  const [successMessage, setSuccessMessage] = useState("")
  const [errorMessage, setErrorMessage] = useState("")

  const [profileData, setProfileData] = useState({
    firstName: "Sophie",
    lastName: "Martin",
    email: "sophie.martin@example.com",
    phone: "06 12 34 56 78",
    address: "15 rue des Lilas",
    postalCode: "92230",
    city: "Gennevilliers",
  })

  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })

  const [notificationSettings, setNotificationSettings] = useState({
    emailAppointment: true,
    emailInvoice: true,
    emailPromotion: false,
    smsAppointment: true,
    smsInvoice: false,
    smsPromotion: false,
  })

  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setProfileData((prev) => ({ ...prev, [name]: value }))
  }

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setPasswordData((prev) => ({ ...prev, [name]: value }))
  }

  const handleNotificationChange = (name: string, checked: boolean) => {
    setNotificationSettings((prev) => ({ ...prev, [name]: checked }))
  }

  const handleProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Dans une application réelle, vous enverriez ces données à votre API
    setSuccessMessage("Vos informations personnelles ont été mises à jour avec succès.")
    setTimeout(() => setSuccessMessage(""), 3000)
  }

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Vérification des mots de passe
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      setErrorMessage("Les mots de passe ne correspondent pas.")
      setTimeout(() => setErrorMessage(""), 3000)
      return
    }

    // Dans une application réelle, vous enverriez ces données à votre API
    setSuccessMessage("Votre mot de passe a été modifié avec succès.")
    setTimeout(() => setSuccessMessage(""), 3000)

    // Réinitialiser le formulaire
    setPasswordData({
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    })
  }

  const handleNotificationSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Dans une application réelle, vous enverriez ces données à votre API
    setSuccessMessage("Vos préférences de notification ont été mises à jour avec succès.")
    setTimeout(() => setSuccessMessage(""), 3000)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-montserrat text-2xl font-bold text-navy-blue md:text-3xl">Paramètres du compte</h1>
        <p className="mt-1 text-gray-500">Gérez vos informations personnelles et vos préférences</p>
      </div>

      {successMessage && (
        <Alert className="bg-green-50 text-green-800">
          <Check className="h-4 w-4 text-green-500" />
          <AlertDescription>{successMessage}</AlertDescription>
        </Alert>
      )}

      {errorMessage && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{errorMessage}</AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="profile" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="profile">Profil</TabsTrigger>
          <TabsTrigger value="password">Mot de passe</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Informations personnelles</CardTitle>
              <CardDescription>
                Mettez à jour vos informations personnelles. Ces informations seront utilisées pour les rendez-vous et
                les factures.
              </CardDescription>
            </CardHeader>
            <form onSubmit={handleProfileSubmit}>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">Prénom</Label>
                    <Input
                      id="firstName"
                      name="firstName"
                      value={profileData.firstName}
                      onChange={handleProfileChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Nom</Label>
                    <Input
                      id="lastName"
                      name="lastName"
                      value={profileData.lastName}
                      onChange={handleProfileChange}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={profileData.email}
                      onChange={handleProfileChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Téléphone</Label>
                    <Input id="phone" name="phone" value={profileData.phone} onChange={handleProfileChange} required />
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label htmlFor="address">Adresse</Label>
                  <Input id="address" name="address" value={profileData.address} onChange={handleProfileChange} />
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="postalCode">Code postal</Label>
                    <Input
                      id="postalCode"
                      name="postalCode"
                      value={profileData.postalCode}
                      onChange={handleProfileChange}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="city">Ville</Label>
                    <Input id="city" name="city" value={profileData.city} onChange={handleProfileChange} />
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button type="submit">Enregistrer les modifications</Button>
              </CardFooter>
            </form>
          </Card>
        </TabsContent>

        <TabsContent value="password" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Changer de mot de passe</CardTitle>
              <CardDescription>Mettez à jour votre mot de passe pour sécuriser votre compte.</CardDescription>
            </CardHeader>
            <form onSubmit={handlePasswordSubmit}>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="currentPassword">Mot de passe actuel</Label>
                  <Input
                    id="currentPassword"
                    name="currentPassword"
                    type="password"
                    value={passwordData.currentPassword}
                    onChange={handlePasswordChange}
                    required
                  />
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label htmlFor="newPassword">Nouveau mot de passe</Label>
                  <Input
                    id="newPassword"
                    name="newPassword"
                    type="password"
                    value={passwordData.newPassword}
                    onChange={handlePasswordChange}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirmer le nouveau mot de passe</Label>
                  <Input
                    id="confirmPassword"
                    name="confirmPassword"
                    type="password"
                    value={passwordData.confirmPassword}
                    onChange={handlePasswordChange}
                    required
                  />
                </div>
              </CardContent>
              <CardFooter>
                <Button type="submit">Changer le mot de passe</Button>
              </CardFooter>
            </form>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Préférences de notification</CardTitle>
              <CardDescription>
                Choisissez comment vous souhaitez être informé des événements importants.
              </CardDescription>
            </CardHeader>
            <form onSubmit={handleNotificationSubmit}>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="mb-4 text-lg font-medium">Notifications par email</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="emailAppointment" className="font-medium">
                          Rappels de rendez-vous
                        </Label>
                        <p className="text-sm text-gray-500">Recevez un email de rappel 24h avant votre rendez-vous</p>
                      </div>
                      <Switch
                        id="emailAppointment"
                        checked={notificationSettings.emailAppointment}
                        onCheckedChange={(checked) => handleNotificationChange("emailAppointment", checked)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="emailInvoice" className="font-medium">
                          Nouvelles factures
                        </Label>
                        <p className="text-sm text-gray-500">
                          Recevez un email lorsqu'une nouvelle facture est disponible
                        </p>
                      </div>
                      <Switch
                        id="emailInvoice"
                        checked={notificationSettings.emailInvoice}
                        onCheckedChange={(checked) => handleNotificationChange("emailInvoice", checked)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="emailPromotion" className="font-medium">
                          Offres promotionnelles
                        </Label>
                        <p className="text-sm text-gray-500">
                          Recevez des offres spéciales et des promotions par email
                        </p>
                      </div>
                      <Switch
                        id="emailPromotion"
                        checked={notificationSettings.emailPromotion}
                        onCheckedChange={(checked) => handleNotificationChange("emailPromotion", checked)}
                      />
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <h3 className="mb-4 text-lg font-medium">Notifications par SMS</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="smsAppointment" className="font-medium">
                          Rappels de rendez-vous
                        </Label>
                        <p className="text-sm text-gray-500">Recevez un SMS de rappel 24h avant votre rendez-vous</p>
                      </div>
                      <Switch
                        id="smsAppointment"
                        checked={notificationSettings.smsAppointment}
                        onCheckedChange={(checked) => handleNotificationChange("smsAppointment", checked)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="smsInvoice" className="font-medium">
                          Nouvelles factures
                        </Label>
                        <p className="text-sm text-gray-500">
                          Recevez un SMS lorsqu'une nouvelle facture est disponible
                        </p>
                      </div>
                      <Switch
                        id="smsInvoice"
                        checked={notificationSettings.smsInvoice}
                        onCheckedChange={(checked) => handleNotificationChange("smsInvoice", checked)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="smsPromotion" className="font-medium">
                          Offres promotionnelles
                        </Label>
                        <p className="text-sm text-gray-500">Recevez des offres spéciales et des promotions par SMS</p>
                      </div>
                      <Switch
                        id="smsPromotion"
                        checked={notificationSettings.smsPromotion}
                        onCheckedChange={(checked) => handleNotificationChange("smsPromotion", checked)}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button type="submit">Enregistrer les préférences</Button>
              </CardFooter>
            </form>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
