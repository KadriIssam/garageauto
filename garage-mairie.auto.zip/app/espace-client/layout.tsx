import type React from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { User, Calendar, FileText, Clock, Car, Settings, ChevronRight, Menu } from "lucide-react"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import LogoutButton from "@/components/logout-button"

interface ClientLayoutProps {
  children: React.ReactNode
}

const navigation = [
  {
    name: "Tableau de bord",
    href: "/espace-client/tableau-de-bord",
    icon: <User className="mr-2 h-5 w-5" />,
  },
  {
    name: "Mes rendez-vous",
    href: "/espace-client/rendez-vous",
    icon: <Calendar className="mr-2 h-5 w-5" />,
  },
  {
    name: "Historique d'interventions",
    href: "/espace-client/historique",
    icon: <Clock className="mr-2 h-5 w-5" />,
  },
  {
    name: "Mes factures",
    href: "/espace-client/factures",
    icon: <FileText className="mr-2 h-5 w-5" />,
  },
  {
    name: "Mes véhicules",
    href: "/espace-client/vehicules",
    icon: <Car className="mr-2 h-5 w-5" />,
  },
  {
    name: "Paramètres du compte",
    href: "/espace-client/parametres",
    icon: <Settings className="mr-2 h-5 w-5" />,
  },
]

export default async function ClientLayout({ children }: ClientLayoutProps) {
  // Vérifier si l'utilisateur est connecté
  // Remplacer la fonction requireAuth par une version simplifiée pour le développement

  // Remplacer cette ligne :
  // const user = await requireAuth()

  // Par celle-ci :
  const user = { id: "dev-user-id", email: "dev@example.com" }

  // Et remplacer cette partie :
  // const supabase = createClient()
  // const { data: userData } = await supabase.from("users").select("first_name, last_name").eq("id", user.id).single()
  // const fullName = userData ? `${userData.first_name} ${userData.last_name}` : user.email

  // Par celle-ci :
  const fullName = "Utilisateur Test"

  return (
    <div className="container mx-auto px-4 py-8 sm:px-6 lg:px-8">
      <div className="flex flex-col space-y-8 lg:flex-row lg:space-x-8 lg:space-y-0">
        {/* Sidebar pour desktop */}
        <aside className="hidden w-64 shrink-0 lg:block">
          <Card className="sticky top-24">
            <div className="flex flex-col space-y-1 p-6">
              <h2 className="font-montserrat text-xl font-bold text-navy-blue">Espace Client</h2>
              <p className="text-sm text-gray-500">Bienvenue, {fullName}</p>
            </div>
            <Separator />
            <nav className="flex flex-col p-4">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className="flex items-center rounded-md px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-navy-blue"
                >
                  {item.icon}
                  {item.name}
                </Link>
              ))}
              <Separator className="my-4" />
              <LogoutButton />
            </nav>
          </Card>
        </aside>

        {/* Sidebar mobile */}
        <div className="lg:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" className="mb-4 w-full justify-between">
                <span className="flex items-center">
                  <Menu className="mr-2 h-5 w-5" />
                  Menu Espace Client
                </span>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[300px] sm:w-[400px]">
              <div className="flex flex-col space-y-1 py-6">
                <h2 className="font-montserrat text-xl font-bold text-navy-blue">Espace Client</h2>
                <p className="text-sm text-gray-500">Bienvenue, {fullName}</p>
              </div>
              <Separator />
              <nav className="flex flex-col py-4">
                {navigation.map((item) => (
                  <Link
                    key={item.name}
                    href={item.href}
                    className="flex items-center rounded-md px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-navy-blue"
                  >
                    {item.icon}
                    {item.name}
                  </Link>
                ))}
                <Separator className="my-4" />
                <LogoutButton />
              </nav>
            </SheetContent>
          </Sheet>
        </div>

        {/* Contenu principal */}
        <main className="flex-1">{children}</main>
      </div>
    </div>
  )
}
