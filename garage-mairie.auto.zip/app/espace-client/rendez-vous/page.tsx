"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock } from "lucide-react"

export default function ClientAppointments() {
  const [activeTab, setActiveTab] = useState("upcoming")

  // Données fictives pour les rendez-vous
  const appointments = {
    upcoming: [
      {
        id: 1,
        service: "Révision complète",
        date: "10 mai 2025",
        time: "14:30",
        vehicle: "Renault Clio (2018)",
        status: "confirmed",
      },
    ],
    past: [
      {
        id: 2,
        service: "Vidange et filtres",
        date: "15 février 2025",
        time: "10:00",
        vehicle: "Renault Clio (2018)",
        status: "completed",
      },
      {
        id: 3,
        service: "Remplacement plaquettes de frein",
        date: "10 novembre 2024",
        time: "09:30",
        vehicle: "Renault Clio (2018)",
        status: "completed",
      },
    ],
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "confirmed":
        return <Badge className="bg-green-500">Confirmé</Badge>
      case "pending":
        return <Badge className="bg-amber-500">En attente</Badge>
      case "completed":
        return <Badge className="bg-blue-500">Terminé</Badge>
      case "cancelled":
        return <Badge className="bg-red-500">Annulé</Badge>
      default:
        return <Badge className="bg-gray-500">Inconnu</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-montserrat text-2xl font-bold text-navy-blue md:text-3xl">Mes rendez-vous</h1>
        <p className="mt-1 text-gray-500">Consultez et gérez vos rendez-vous</p>
      </div>

      <div className="flex justify-between items-center">
        <Tabs defaultValue="upcoming" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="flex justify-between items-center">
            <TabsList>
              <TabsTrigger value="upcoming">À venir</TabsTrigger>
              <TabsTrigger value="past">Passés</TabsTrigger>
            </TabsList>
            <Button asChild>
              <Link href="/rendez-vous">Nouveau rendez-vous</Link>
            </Button>
          </div>

          <TabsContent value="upcoming">
            {appointments.upcoming.length > 0 ? (
              <div className="space-y-4 mt-6">
                {appointments.upcoming.map((appointment) => (
                  <Card key={appointment.id}>
                    <CardContent className="p-6">
                      <div className="flex flex-col space-y-4 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
                        <div>
                          <p className="font-semibold">{appointment.service}</p>
                          <div className="mt-1 flex items-center text-sm text-gray-500">
                            <Calendar className="mr-1 h-4 w-4" />
                            <span>
                              {appointment.date} à {appointment.time}
                            </span>
                          </div>
                          <p className="mt-1 text-sm text-gray-500">Véhicule: {appointment.vehicle}</p>
                          <div className="mt-2">{getStatusBadge(appointment.status)}</div>
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm" asChild>
                            <Link href={`/espace-client/rendez-vous/${appointment.id}`}>Détails</Link>
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-red-600 hover:bg-red-50 hover:text-red-700"
                          >
                            Annuler
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="mt-6">
                <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                  <Calendar className="h-12 w-12 text-gray-300" />
                  <p className="mt-2 text-gray-500">Vous n'avez pas de rendez-vous à venir</p>
                  <Button className="mt-4" asChild>
                    <Link href="/rendez-vous">Prendre rendez-vous</Link>
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="past">
            {appointments.past.length > 0 ? (
              <div className="space-y-4 mt-6">
                {appointments.past.map((appointment) => (
                  <Card key={appointment.id}>
                    <CardContent className="p-6">
                      <div className="flex flex-col space-y-4 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
                        <div>
                          <p className="font-semibold">{appointment.service}</p>
                          <div className="mt-1 flex items-center text-sm text-gray-500">
                            <Clock className="mr-1 h-4 w-4" />
                            <span>
                              {appointment.date} à {appointment.time}
                            </span>
                          </div>
                          <p className="mt-1 text-sm text-gray-500">Véhicule: {appointment.vehicle}</p>
                          <div className="mt-2">{getStatusBadge(appointment.status)}</div>
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm" asChild>
                            <Link href={`/espace-client/rendez-vous/${appointment.id}`}>Détails</Link>
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="mt-6">
                <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                  <Clock className="h-12 w-12 text-gray-300" />
                  <p className="mt-2 text-gray-500">Vous n'avez pas de rendez-vous passés</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
