"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Car, Calendar, Gauge, Plus, FileText, PenToolIcon as Tool } from "lucide-react"

export default function ClientVehicles() {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [newVehicle, setNewVehicle] = useState({
    make: "",
    model: "",
    year: "",
    registration: "",
    mileage: "",
  })

  // Données fictives pour les véhicules
  const vehicles = [
    {
      id: 1,
      make: "Renault",
      model: "Clio",
      year: 2018,
      registration: "AB-123-CD",
      mileage: 45000,
      lastService: "15 février 2025",
      image: "/placeholder.svg?height=200&width=300",
    },
  ]

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setNewVehicle((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setNewVehicle((prev) => ({ ...prev, [name]: value }))
  }

  const handleAddVehicle = (e: React.FormEvent) => {
    e.preventDefault()
    // Dans une application réelle, vous enverriez ces données à votre API
    console.log("Nouveau véhicule:", newVehicle)
    setIsDialogOpen(false)
    // Réinitialiser le formulaire
    setNewVehicle({
      make: "",
      model: "",
      year: "",
      registration: "",
      mileage: "",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between space-y-4 sm:flex-row sm:items-center sm:space-y-0">
        <div>
          <h1 className="font-montserrat text-2xl font-bold text-navy-blue md:text-3xl">Mes véhicules</h1>
          <p className="mt-1 text-gray-500">Gérez les informations de vos véhicules</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Ajouter un véhicule
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Ajouter un véhicule</DialogTitle>
              <DialogDescription>
                Renseignez les informations de votre véhicule pour faciliter la prise de rendez-vous et le suivi
                d'entretien.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAddVehicle}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="make">Marque</Label>
                    <Select value={newVehicle.make} onValueChange={(value) => handleSelectChange("make", value)}>
                      <SelectTrigger id="make">
                        <SelectValue placeholder="Sélectionner" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="renault">Renault</SelectItem>
                        <SelectItem value="peugeot">Peugeot</SelectItem>
                        <SelectItem value="citroen">Citroën</SelectItem>
                        <SelectItem value="volkswagen">Volkswagen</SelectItem>
                        <SelectItem value="toyota">Toyota</SelectItem>
                        <SelectItem value="autre">Autre</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="model">Modèle</Label>
                    <Input
                      id="model"
                      name="model"
                      value={newVehicle.model}
                      onChange={handleInputChange}
                      placeholder="Ex: Clio"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="year">Année</Label>
                    <Input
                      id="year"
                      name="year"
                      value={newVehicle.year}
                      onChange={handleInputChange}
                      placeholder="Ex: 2018"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="registration">Immatriculation</Label>
                    <Input
                      id="registration"
                      name="registration"
                      value={newVehicle.registration}
                      onChange={handleInputChange}
                      placeholder="Ex: AB-123-CD"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="mileage">Kilométrage actuel</Label>
                  <Input
                    id="mileage"
                    name="mileage"
                    value={newVehicle.mileage}
                    onChange={handleInputChange}
                    placeholder="Ex: 45000"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit">Ajouter le véhicule</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
        {vehicles.map((vehicle) => (
          <Card key={vehicle.id} className="overflow-hidden">
            <div className="relative h-48 w-full">
              <Image
                src={vehicle.image || "/placeholder.svg"}
                alt={`${vehicle.make} ${vehicle.model}`}
                fill
                className="object-cover"
              />
            </div>
            <CardContent className="p-6">
              <h3 className="mb-2 font-montserrat text-xl font-semibold text-navy-blue">
                {vehicle.make} {vehicle.model} ({vehicle.year})
              </h3>
              <div className="mb-4 grid grid-cols-2 gap-2">
                <div className="flex items-center text-sm text-gray-600">
                  <Calendar className="mr-1 h-4 w-4" />
                  <span>Année: {vehicle.year}</span>
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Gauge className="mr-1 h-4 w-4" />
                  <span>{vehicle.mileage.toLocaleString()} km</span>
                </div>
                <div className="col-span-2 flex items-center text-sm text-gray-600">
                  <Car className="mr-1 h-4 w-4" />
                  <span>Immatriculation: {vehicle.registration}</span>
                </div>
              </div>
              <p className="text-sm text-gray-600">
                <span className="font-semibold">Dernier entretien:</span> {vehicle.lastService}
              </p>
            </CardContent>
            <CardFooter className="flex justify-between p-6 pt-0">
              <Button variant="outline" size="sm" asChild>
                <Link href={`/espace-client/vehicules/${vehicle.id}/historique`}>
                  <FileText className="mr-2 h-4 w-4" />
                  Historique
                </Link>
              </Button>
              <Button variant="outline" size="sm" asChild>
                <Link href={`/rendez-vous?vehicule=${vehicle.id}`}>
                  <Tool className="mr-2 h-4 w-4" />
                  Entretien
                </Link>
              </Button>
            </CardFooter>
          </Card>
        ))}

        {/* Carte pour ajouter un véhicule */}
        <Card className="flex h-full flex-col items-center justify-center p-6 text-center">
          <Car className="h-16 w-16 text-gray-300" />
          <h3 className="mt-4 font-montserrat text-lg font-semibold text-navy-blue">Ajouter un véhicule</h3>
          <p className="mt-2 text-sm text-gray-500">
            Ajoutez vos véhicules pour faciliter la prise de rendez-vous et le suivi d'entretien
          </p>
          <Button className="mt-4" onClick={() => setIsDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Ajouter un véhicule
          </Button>
        </Card>
      </div>
    </div>
  )
}
