import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Clock, Car, PenToolIcon as Tool, FileText } from "lucide-react"

export default function ServiceHistory() {
  // Données fictives pour l'historique des interventions
  const serviceHistory = [
    {
      id: 1,
      date: "15 février 2025",
      service: "Vidange et filtres",
      vehicle: "Renault Clio (2018)",
      technician: "Jean Dupont",
      cost: "89,00 €",
      status: "completed",
      details: [
        "Vidange huile moteur 5W30",
        "Remplacement filtre à huile",
        "Remplacement filtre à air",
        "Vérification des niveaux",
        "Contrôle pression des pneus",
      ],
      recommendations: ["Prévoir remplacement des plaquettes de frein avant dans les 5000 km"],
      invoiceId: 1,
    },
    {
      id: 2,
      date: "10 novembre 2024",
      service: "Remplacement plaquettes de frein",
      vehicle: "Renault Clio (2018)",
      technician: "Michel Martin",
      cost: "145,00 €",
      status: "completed",
      details: [
        "Remplacement plaquettes de frein avant",
        "Vérification disques de frein",
        "Contrôle système de freinage",
      ],
      recommendations: ["Prévoir révision complète dans les 3 mois"],
      invoiceId: 2,
    },
    {
      id: 3,
      date: "5 juin 2024",
      service: "Révision complète",
      vehicle: "Renault Clio (2018)",
      technician: "Jean Dupont",
      cost: "210,00 €",
      status: "completed",
      details: [
        "Vidange huile moteur",
        "Remplacement tous filtres",
        "Contrôle freinage",
        "Contrôle suspension",
        "Contrôle éclairage",
        "Diagnostic électronique",
        "Contrôle batterie",
      ],
      recommendations: ["Prévoir remplacement courroie d'accessoires dans les 10000 km"],
      invoiceId: 3,
    },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-montserrat text-2xl font-bold text-navy-blue md:text-3xl">Historique d'interventions</h1>
        <p className="mt-1 text-gray-500">Consultez l'historique des interventions sur vos véhicules</p>
      </div>

      <div className="space-y-4">
        {serviceHistory.map((service) => (
          <Card key={service.id}>
            <CardHeader className="pb-2">
              <div className="flex flex-col justify-between space-y-2 sm:flex-row sm:items-center sm:space-y-0">
                <CardTitle className="text-lg">{service.service}</CardTitle>
                <Badge className="w-fit bg-blue-500">Terminé</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock className="mr-2 h-4 w-4" />
                    <span>{service.date}</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Car className="mr-2 h-4 w-4" />
                    <span>{service.vehicle}</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Tool className="mr-2 h-4 w-4" />
                    <span>Technicien: {service.technician}</span>
                  </div>
                </div>
                <div className="flex flex-col items-start justify-center space-y-2 sm:items-end">
                  <p className="text-lg font-semibold">{service.cost}</p>
                  <Button variant="outline" size="sm" asChild>
                    <Link href={`/espace-client/factures/${service.invoiceId}`}>
                      <FileText className="mr-2 h-4 w-4" />
                      Voir la facture
                    </Link>
                  </Button>
                </div>
              </div>

              <Accordion type="single" collapsible className="mt-4">
                <AccordionItem value="details">
                  <AccordionTrigger>Détails de l'intervention</AccordionTrigger>
                  <AccordionContent>
                    <ul className="ml-6 list-disc space-y-1 text-sm text-gray-600">
                      {service.details.map((detail, index) => (
                        <li key={index}>{detail}</li>
                      ))}
                    </ul>
                  </AccordionContent>
                </AccordionItem>
                {service.recommendations.length > 0 && (
                  <AccordionItem value="recommendations">
                    <AccordionTrigger>Recommandations</AccordionTrigger>
                    <AccordionContent>
                      <ul className="ml-6 list-disc space-y-1 text-sm text-gray-600">
                        {service.recommendations.map((recommendation, index) => (
                          <li key={index}>{recommendation}</li>
                        ))}
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                )}
              </Accordion>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
