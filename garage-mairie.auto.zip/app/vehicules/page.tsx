import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Fuel, Gauge, Euro, Phone } from "lucide-react"

export default function VehiclesPage() {
  const vehicles = [
    {
      id: 1,
      title: "Renault Clio IV",
      year: 2018,
      mileage: 45000,
      fuel: "Essence",
      price: 9800,
      image: "/placeholder.svg?height=200&width=300",
      featured: true,
    },
    {
      id: 2,
      title: "Peugeot 308",
      year: 2019,
      mileage: 38000,
      fuel: "Diesel",
      price: 12500,
      image: "/placeholder.svg?height=200&width=300",
      featured: false,
    },
    {
      id: 3,
      title: "Citroën C3",
      year: 2020,
      mileage: 25000,
      fuel: "Essence",
      price: 11200,
      image: "/placeholder.svg?height=200&width=300",
      featured: true,
    },
    {
      id: 4,
      title: "Volkswagen Golf VII",
      year: 2017,
      mileage: 62000,
      fuel: "Diesel",
      price: 13800,
      image: "/placeholder.svg?height=200&width=300",
      featured: false,
    },
    {
      id: 5,
      title: "Dacia Sandero",
      year: 2021,
      mileage: 18000,
      fuel: "Essence",
      price: 10500,
      image: "/placeholder.svg?height=200&width=300",
      featured: false,
    },
    {
      id: 6,
      title: "Toyota Yaris Hybride",
      year: 2019,
      mileage: 32000,
      fuel: "Hybride",
      price: 14200,
      image: "/placeholder.svg?height=200&width=300",
      featured: true,
    },
  ]

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-navy-blue py-16 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="font-montserrat text-4xl font-bold md:text-5xl">Véhicules à vendre</h1>
            <p className="mt-6 text-lg text-gray-300">
              Découvrez notre sélection de véhicules d'occasion contrôlés et garantis
            </p>
          </div>
        </div>
      </section>

      {/* Vehicles Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="mb-8 flex w-full flex-wrap justify-center gap-2">
              <TabsTrigger value="all">Tous les véhicules</TabsTrigger>
              <TabsTrigger value="featured">Véhicules à la une</TabsTrigger>
            </TabsList>

            <TabsContent value="all">
              <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
                {vehicles.map((vehicle) => (
                  <VehicleCard key={vehicle.id} vehicle={vehicle} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="featured">
              <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
                {vehicles
                  .filter((vehicle) => vehicle.featured)
                  .map((vehicle) => (
                    <VehicleCard key={vehicle.id} vehicle={vehicle} />
                  ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Sell Your Car Section */}
      <section className="bg-gray-50 py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="font-montserrat text-3xl font-bold text-navy-blue md:text-4xl">
              Vous souhaitez vendre votre véhicule ?
            </h2>
            <p className="mt-6 text-lg text-gray-600">
              Nous proposons des reprises de véhicules à des tarifs compétitifs. Contactez-nous pour une estimation
              gratuite et sans engagement.
            </p>
            <div className="mt-8">
              <Button size="lg" asChild>
                <Link href="/contact">
                  <Phone className="mr-2 h-5 w-5" />
                  Nous contacter
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

interface VehicleCardProps {
  vehicle: {
    id: number
    title: string
    year: number
    mileage: number
    fuel: string
    price: number
    image: string
    featured: boolean
  }
}

function VehicleCard({ vehicle }: VehicleCardProps) {
  return (
    <Card className="h-full overflow-hidden">
      <div className="relative">
        <div className="relative h-48 w-full">
          <Image src={vehicle.image || "/placeholder.svg"} alt={vehicle.title} fill className="object-cover" />
        </div>
        {vehicle.featured && (
          <Badge className="absolute right-2 top-2 bg-yellow-500 text-white hover:bg-yellow-600">À la une</Badge>
        )}
      </div>
      <CardContent className="pt-6">
        <h3 className="mb-2 font-montserrat text-xl font-semibold text-navy-blue">{vehicle.title}</h3>
        <div className="mb-4 grid grid-cols-2 gap-2">
          <div className="flex items-center text-sm text-gray-600">
            <Calendar className="mr-1 h-4 w-4" />
            <span>{vehicle.year}</span>
          </div>
          <div className="flex items-center text-sm text-gray-600">
            <Gauge className="mr-1 h-4 w-4" />
            <span>{vehicle.mileage.toLocaleString()} km</span>
          </div>
          <div className="flex items-center text-sm text-gray-600">
            <Fuel className="mr-1 h-4 w-4" />
            <span>{vehicle.fuel}</span>
          </div>
          <div className="flex items-center text-sm font-semibold text-navy-blue">
            <Euro className="mr-1 h-4 w-4" />
            <span>{vehicle.price.toLocaleString()} €</span>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <div className="flex w-full gap-2">
          <Button variant="outline" className="flex-1" asChild>
            <Link href={`/vehicules/${vehicle.id}`}>Détails</Link>
          </Button>
          <Button className="flex-1" asChild>
            <Link href={`/contact?vehicle=${vehicle.id}`}>Contact</Link>
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}
