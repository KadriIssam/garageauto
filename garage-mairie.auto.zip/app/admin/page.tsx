"use client"

import { useState } from "react"
import { Calendar } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart, Users, Car, PenToolIcon as Tool, ShoppingCart } from "lucide-react"
import AdminAppointments from "@/components/admin/admin-appointments"
import AdminClients from "@/components/admin/admin-clients"
import AdminInventory from "@/components/admin/admin-inventory"
import AdminDashboard from "@/components/admin/admin-dashboard"

export default function AdminPage() {
  // Utiliser un état pour suivre l'onglet actif
  const [activeTab, setActiveTab] = useState("dashboard")

  // Vérification d'admin désactivée pour le développement
  // await requireAdmin()

  // Récupérer les informations de l'administrateur
  // const supabase = createClient()
  // const {
  //   data: { user },
  // } = await supabase.auth.getUser()

  // if (!user) {
  //   redirect("/espace-client/connexion")
  // }
  const user = { id: "dev-admin-id", email: "admin@example.com" }

  return (
    <div className="container mx-auto px-4 py-8 sm:px-6 lg:px-8">
      <h1 className="mb-6 font-montserrat text-2xl font-bold text-navy-blue md:text-3xl">
        Tableau de bord administrateur
      </h1>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="mb-8 flex w-full flex-wrap justify-start gap-2">
          <TabsTrigger value="dashboard" className="flex items-center gap-2">
            <BarChart className="h-4 w-4" />
            Tableau de bord
          </TabsTrigger>
          <TabsTrigger value="appointments" className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            Rendez-vous
          </TabsTrigger>
          <TabsTrigger value="clients" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Clients
          </TabsTrigger>
          <TabsTrigger value="vehicles" className="flex items-center gap-2">
            <Car className="h-4 w-4" />
            Véhicules
          </TabsTrigger>
          <TabsTrigger value="services" className="flex items-center gap-2">
            <Tool className="h-4 w-4" />
            Services
          </TabsTrigger>
          <TabsTrigger value="inventory" className="flex items-center gap-2">
            <ShoppingCart className="h-4 w-4" />
            Inventaire
          </TabsTrigger>
        </TabsList>

        <div className="mt-4">
          {activeTab === "dashboard" && <AdminDashboard />}
          {activeTab === "appointments" && <AdminAppointments />}
          {activeTab === "clients" && <AdminClients />}
          {activeTab === "vehicles" && (
            <Card>
              <CardHeader>
                <CardTitle>Gestion des véhicules</CardTitle>
                <CardDescription>Gérez les véhicules à vendre et les annonces</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500">Fonctionnalité en cours de développement...</p>
              </CardContent>
            </Card>
          )}
          {activeTab === "services" && (
            <Card>
              <CardHeader>
                <CardTitle>Gestion des services</CardTitle>
                <CardDescription>Gérez les services proposés et les tarifs</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500">Fonctionnalité en cours de développement...</p>
              </CardContent>
            </Card>
          )}
          {activeTab === "inventory" && <AdminInventory />}
        </div>
      </Tabs>
    </div>
  )
}
