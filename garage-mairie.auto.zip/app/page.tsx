import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CalendarClock, Car, PenToolIcon as Tool, Wrench, ShieldCheck, Users, Star } from "lucide-react"
import ServiceCard from "@/components/service-card"
import TestimonialCard from "@/components/testimonial-card"
import AppointmentCTA from "@/components/appointment-cta"

export default function Home() {
  const services = [
    {
      id: 1,
      title: "Mécanique générale",
      description: "Réparations moteur, transmission, freins et suspension",
      icon: <Wrench className="h-10 w-10 text-navy-blue" />,
      href: "/services/mecanique",
    },
    {
      id: 2,
      title: "Entretien régulier",
      description: "Vidange, filtres, courroie de distribution et pneumatiques",
      icon: <Tool className="h-10 w-10 text-navy-blue" />,
      href: "/services/entretien",
    },
    {
      id: 3,
      title: "Diagnostic électronique",
      description: "Analyse complète des systèmes électroniques de votre véhicule",
      icon: <ShieldCheck className="h-10 w-10 text-navy-blue" />,
      href: "/services/diagnostic",
    },
    {
      id: 4,
      title: "Vente de véhicules",
      description: "Large sélection de véhicules d'occasion contrôlés et garantis",
      icon: <Car className="h-10 w-10 text-navy-blue" />,
      href: "/vehicules",
    },
  ]

  const testimonials = [
    {
      id: 1,
      name: "Sophie Martin",
      role: "Cliente particulière",
      content:
        "Service impeccable et rapide. J'ai apprécié la transparence sur les réparations à effectuer et les tarifs appliqués.",
      rating: 5,
    },
    {
      id: 2,
      name: "Thomas Dubois",
      role: "Artisan",
      content:
        "Je confie l'entretien de ma camionnette au Garage de la Mairie depuis 3 ans. Équipe professionnelle et réactive.",
      rating: 5,
    },
    {
      id: 3,
      name: "Entreprise Logistique XYZ",
      role: "Client professionnel",
      content: "Notre flotte de 5 véhicules est entretenue par le garage. Suivi rigoureux et conseils pertinents.",
      rating: 4,
    },
  ]

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative bg-navy-blue py-20 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-12 md:grid-cols-2">
            <div className="flex flex-col justify-center">
              <Badge className="mb-4 w-fit bg-white text-navy-blue">Garage automobile à Gennevilliers</Badge>
              <h1 className="font-montserrat text-4xl font-bold leading-tight md:text-5xl">
                Réparations Toutes Marques
              </h1>
              <p className="mt-6 text-lg text-gray-300">
                À votre service depuis 2007. Notre équipe de professionnels prend soin de votre automobile pour une
                puissance et des performances optimales.
              </p>
              <div className="mt-8 flex flex-wrap gap-4">
                <Button size="lg" asChild>
                  <Link href="/rendez-vous">
                    <CalendarClock className="mr-2 h-5 w-5" />
                    Prendre rendez-vous
                  </Link>
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-navy-blue"
                  asChild
                >
                  <Link href="/services">Nos services</Link>
                </Button>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <div className="relative h-[300px] w-full overflow-hidden rounded-lg sm:h-[400px]">
                <Image
                  src="/placeholder.svg?key=2bljt"
                  alt="Garage de la Mairie Kadri"
                  fill
                  className="object-cover"
                  priority
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="font-montserrat text-3xl font-bold text-navy-blue md:text-4xl">Nos services</h2>
            <p className="mx-auto mt-4 max-w-2xl text-lg text-gray-600">
              Des prestations complètes pour l'entretien et la réparation de votre véhicule
            </p>
          </div>
          <div className="mt-12 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {services.map((service) => (
              <ServiceCard key={service.id} service={service} />
            ))}
          </div>
          <div className="mt-12 text-center">
            <Button size="lg" variant="outline" asChild>
              <Link href="/services">Voir tous nos services</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="bg-gray-50 py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-12 md:grid-cols-2">
            <div className="relative h-[300px] overflow-hidden rounded-lg sm:h-[400px]">
              <Image
                src="/placeholder.svg?key=a2h5c"
                alt="L'équipe du Garage de la Mairie"
                fill
                className="object-cover"
              />
            </div>
            <div className="flex flex-col justify-center">
              <h2 className="font-montserrat text-3xl font-bold text-navy-blue md:text-4xl">
                À propos du Garage de la Mairie
              </h2>
              <p className="mt-6 text-lg text-gray-600">
                Depuis 2007, notre garage automobile situé à Gennevilliers met son expertise au service de votre
                véhicule. Notre équipe de mécaniciens qualifiés s'engage à vous offrir un service de qualité,
                transparent et personnalisé pour toutes les marques de véhicules.
              </p>
              <div className="mt-8 grid grid-cols-2 gap-4">
                <div className="flex items-center">
                  <Users className="mr-3 h-8 w-8 text-navy-blue" />
                  <div>
                    <p className="font-montserrat text-xl font-bold text-navy-blue">15+</p>
                    <p className="text-sm text-gray-600">Années d'expérience</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <Star className="mr-3 h-8 w-8 text-navy-blue" />
                  <div>
                    <p className="font-montserrat text-xl font-bold text-navy-blue">4.8/5</p>
                    <p className="text-sm text-gray-600">Note moyenne clients</p>
                  </div>
                </div>
              </div>
              <div className="mt-8">
                <Button asChild>
                  <Link href="/contact">En savoir plus</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="font-montserrat text-3xl font-bold text-navy-blue md:text-4xl">Ce que disent nos clients</h2>
            <p className="mx-auto mt-4 max-w-2xl text-lg text-gray-600">
              Découvrez les témoignages de nos clients satisfaits
            </p>
          </div>
          <div className="mt-12 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {testimonials.map((testimonial) => (
              <TestimonialCard key={testimonial.id} testimonial={testimonial} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <AppointmentCTA />
    </div>
  )
}
