"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { CalendarIcon, CheckCircle } from "lucide-react"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { fr } from "date-fns/locale"

export default function AppointmentPage() {
  const [date, setDate] = useState<Date | undefined>(undefined)
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    service: "",
    vehicleMake: "",
    vehicleModel: "",
    vehicleYear: "",
    name: "",
    email: "",
    phone: "",
    message: "",
    appointmentType: "atelier",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real application, this would send the data to the server
    setStep(3) // Move to confirmation step
  }

  const services = [
    { value: "revision", label: "Révision complète" },
    { value: "vidange", label: "Vidange et filtres" },
    { value: "freins", label: "Système de freinage" },
    { value: "distribution", label: "Courroie de distribution" },
    { value: "diagnostic", label: "Diagnostic électronique" },
    { value: "climatisation", label: "Climatisation" },
    { value: "pneus", label: "Pneumatiques" },
    { value: "autre", label: "Autre (préciser dans le message)" },
  ]

  const timeSlots = [
    { value: "09:00", label: "09:00" },
    { value: "10:00", label: "10:00" },
    { value: "11:00", label: "11:00" },
    { value: "14:00", label: "14:00" },
    { value: "15:00", label: "15:00" },
    { value: "16:00", label: "16:00" },
  ]

  return (
    <div className="container mx-auto px-4 py-16 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-3xl">
        <h1 className="mb-6 text-center font-montserrat text-3xl font-bold text-navy-blue md:text-4xl">
          Prendre rendez-vous
        </h1>
        <p className="mb-12 text-center text-lg text-gray-600">
          Réservez un créneau pour l'entretien ou la réparation de votre véhicule
        </p>

        {step === 1 && (
          <Card>
            <CardHeader>
              <CardTitle>Étape 1 : Informations sur le service</CardTitle>
              <CardDescription>
                Sélectionnez le type de service et fournissez les informations sur votre véhicule
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="appointmentType">Type de rendez-vous</Label>
                    <RadioGroup
                      id="appointmentType"
                      value={formData.appointmentType}
                      onValueChange={(value) => handleSelectChange("appointmentType", value)}
                      className="mt-2 flex flex-col space-y-2 sm:flex-row sm:space-x-4 sm:space-y-0"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="atelier" id="atelier" />
                        <Label htmlFor="atelier">Atelier (sur place)</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="domicile" id="domicile" />
                        <Label htmlFor="domicile">À domicile</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div>
                    <Label htmlFor="service">Service requis</Label>
                    <Select value={formData.service} onValueChange={(value) => handleSelectChange("service", value)}>
                      <SelectTrigger id="service" className="mt-1">
                        <SelectValue placeholder="Sélectionnez un service" />
                      </SelectTrigger>
                      <SelectContent>
                        {services.map((service) => (
                          <SelectItem key={service.value} value={service.value}>
                            {service.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div>
                      <Label htmlFor="vehicleMake">Marque du véhicule</Label>
                      <Input
                        id="vehicleMake"
                        name="vehicleMake"
                        value={formData.vehicleMake}
                        onChange={handleChange}
                        className="mt-1"
                        placeholder="Ex: Renault"
                      />
                    </div>
                    <div>
                      <Label htmlFor="vehicleModel">Modèle</Label>
                      <Input
                        id="vehicleModel"
                        name="vehicleModel"
                        value={formData.vehicleModel}
                        onChange={handleChange}
                        className="mt-1"
                        placeholder="Ex: Clio"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="vehicleYear">Année</Label>
                    <Input
                      id="vehicleYear"
                      name="vehicleYear"
                      value={formData.vehicleYear}
                      onChange={handleChange}
                      className="mt-1"
                      placeholder="Ex: 2018"
                    />
                  </div>

                  <div>
                    <Label htmlFor="message">Informations complémentaires</Label>
                    <Textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      className="mt-1"
                      placeholder="Décrivez votre problème ou besoin spécifique"
                      rows={4}
                    />
                  </div>
                </div>

                <Button
                  type="button"
                  className="w-full"
                  onClick={() => setStep(2)}
                  disabled={!formData.service || !formData.vehicleMake || !formData.vehicleModel}
                >
                  Continuer
                </Button>
              </form>
            </CardContent>
          </Card>
        )}

        {step === 2 && (
          <Card>
            <CardHeader>
              <CardTitle>Étape 2 : Date et coordonnées</CardTitle>
              <CardDescription>Choisissez une date et fournissez vos coordonnées</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <Label>Date du rendez-vous</Label>
                    <div className="mt-1">
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button variant="outline" className="w-full justify-start text-left font-normal">
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {date ? format(date, "PPP", { locale: fr }) : <span>Sélectionnez une date</span>}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={date}
                            onSelect={setDate}
                            initialFocus
                            locale={fr}
                            disabled={(date) => {
                              // Disable weekends and past dates
                              const day = date.getDay()
                              const today = new Date()
                              today.setHours(0, 0, 0, 0)
                              return date < today || day === 0 || day === 6
                            }}
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="timeSlot">Heure du rendez-vous</Label>
                    <Select>
                      <SelectTrigger id="timeSlot" className="mt-1">
                        <SelectValue placeholder="Sélectionnez une heure" />
                      </SelectTrigger>
                      <SelectContent>
                        {timeSlots.map((slot) => (
                          <SelectItem key={slot.value} value={slot.value}>
                            {slot.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div>
                      <Label htmlFor="name">Nom complet</Label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        className="mt-1"
                        placeholder="Prénom et nom"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone">Téléphone</Label>
                      <Input
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className="mt-1"
                        placeholder="Ex: 06 12 34 56 78"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                      className="mt-1"
                      placeholder="votre@email.com"
                      required
                    />
                  </div>
                </div>

                <div className="flex flex-col space-y-2 sm:flex-row sm:space-x-2 sm:space-y-0">
                  <Button type="button" variant="outline" className="flex-1" onClick={() => setStep(1)}>
                    Retour
                  </Button>
                  <Button
                    type="submit"
                    className="flex-1"
                    disabled={!date || !formData.name || !formData.email || !formData.phone}
                  >
                    Confirmer le rendez-vous
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {step === 3 && (
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col items-center justify-center space-y-4 text-center">
                <CheckCircle className="h-16 w-16 text-green-500" />
                <h2 className="font-montserrat text-2xl font-bold text-navy-blue">Rendez-vous confirmé !</h2>
                <p className="text-gray-600">
                  Votre rendez-vous a été enregistré avec succès. Vous recevrez bientôt un email de confirmation.
                </p>
                <div className="mt-4 w-full max-w-md rounded-lg bg-gray-50 p-4">
                  <h3 className="mb-2 font-montserrat font-semibold">Récapitulatif :</h3>
                  <p className="mb-1 text-sm">
                    <span className="font-semibold">Service :</span>{" "}
                    {services.find((s) => s.value === formData.service)?.label}
                  </p>
                  <p className="mb-1 text-sm">
                    <span className="font-semibold">Véhicule :</span> {formData.vehicleMake} {formData.vehicleModel} (
                    {formData.vehicleYear})
                  </p>
                  <p className="mb-1 text-sm">
                    <span className="font-semibold">Date :</span> {date ? format(date, "PPP", { locale: fr }) : ""}
                  </p>
                  <p className="text-sm">
                    <span className="font-semibold">Type de rendez-vous :</span>{" "}
                    {formData.appointmentType === "atelier" ? "Atelier (sur place)" : "À domicile"}
                  </p>
                </div>
                <Button className="mt-6" onClick={() => (window.location.href = "/")}>
                  Retour à l'accueil
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
