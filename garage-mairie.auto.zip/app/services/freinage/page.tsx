import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { ChevronRight } from "lucide-react"
import AppointmentCTA from "@/components/appointment-cta"

export default function FreinagePage() {
  const services = [
    {
      id: 1,
      title: "Remplacement plaquettes de frein",
      description: "Remplacement des plaquettes de frein avant ou arrière",
      price: "À partir de 89€",
      image: "/placeholder.svg?height=200&width=300&query=brake pads replacement",
    },
    {
      id: 2,
      title: "Remplacement disques de frein",
      description: "Remplacement des disques de frein avant ou arrière",
      price: "À partir de 149€",
      image: "/placeholder.svg?height=200&width=300&query=brake discs replacement",
    },
    {
      id: 3,
      title: "Purge du système de freinage",
      description: "Remplacement du liquide de frein et purge du circuit",
      price: "À partir de 69€",
      image: "/placeholder.svg?height=200&width=300&query=brake fluid change",
    },
    {
      id: 4,
      title: "Réparation étriers de frein",
      description: "Réparation ou remplacement des étriers de frein",
      price: "À partir de 120€",
      image: "/placeholder.svg?height=200&width=300&query=brake caliper repair",
    },
  ]

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-navy-blue py-16 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="font-montserrat text-4xl font-bold md:text-5xl">Services de freinage</h1>
            <p className="mt-6 text-lg text-gray-300">
              Assurez votre sécurité avec nos services de freinage de qualité
            </p>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            {services.map((service) => (
              <Card key={service.id} className="h-full overflow-hidden">
                <div className="relative h-48 w-full">
                  <Image src={service.image || "/placeholder.svg"} alt={service.title} fill className="object-cover" />
                </div>
                <CardContent className="pt-6">
                  <h3 className="mb-2 font-montserrat text-xl font-semibold text-navy-blue">{service.title}</h3>
                  <p className="mb-4 text-gray-600">{service.description}</p>
                  <p className="font-montserrat text-lg font-semibold text-navy-blue">{service.price}</p>
                </CardContent>
                <CardFooter>
                  <Button asChild>
                    <Link href="/rendez-vous">
                      Prendre rendez-vous
                      <ChevronRight className="ml-1 h-4 w-4" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <AppointmentCTA />
    </div>
  )
}
