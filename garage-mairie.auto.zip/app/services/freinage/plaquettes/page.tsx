import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { AlertTriangle, CheckCircle } from "lucide-react"
import AppointmentCTA from "@/components/appointment-cta"

export default function PlaquettesPage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-navy-blue py-16 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="font-montserrat text-4xl font-bold md:text-5xl">Plaquettes de frein</h1>
            <p className="mt-6 text-lg text-gray-300">Assurez votre sécurité avec un système de freinage performant</p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-2">
            <div>
              <h2 className="font-montserrat text-2xl font-bold text-navy-blue md:text-3xl">
                L'importance des plaquettes de frein
              </h2>
              <p className="mt-4 text-lg text-gray-600">
                Les plaquettes de frein sont un élément essentiel du système de freinage de votre véhicule. Elles
                assurent votre sécurité et celle des autres usagers de la route. Des plaquettes usées peuvent
                considérablement augmenter la distance de freinage et compromettre votre sécurité.
              </p>

              <Card className="mt-6 border-amber-300 bg-amber-50">
                <CardContent className="flex items-start p-4">
                  <AlertTriangle className="mr-3 h-6 w-6 flex-shrink-0 text-amber-500" />
                  <div>
                    <h3 className="font-montserrat text-base font-semibold text-amber-800">Attention</h3>
                    <p className="text-amber-700">
                      Des plaquettes de frein usées peuvent entraîner une perte d'efficacité du freinage et augmenter
                      considérablement les distances d'arrêt. Ne négligez pas ce remplacement essentiel pour votre
                      sécurité !
                    </p>
                  </div>
                </CardContent>
              </Card>

              <h3 className="mt-10 font-montserrat text-xl font-semibold text-navy-blue">
                Notre service de remplacement comprend :
              </h3>
              <ul className="mt-4 space-y-2 text-gray-600">
                <li>• Remplacement des plaquettes de frein avant ou arrière</li>
                <li>• Vérification de l'état des disques de frein</li>
                <li>• Contrôle du système de freinage complet</li>
                <li>• Vérification du niveau et de l'état du liquide de frein</li>
                <li>• Nettoyage et graissage des étriers</li>
                <li>• Test de freinage après intervention</li>
              </ul>

              <div className="mt-10">
                <h3 className="font-montserrat text-xl font-semibold text-navy-blue">Tarifs :</h3>
                <p className="mt-2 text-lg text-gray-600">
                  <span className="font-semibold">Plaquettes avant :</span> à partir de 89€
                </p>
                <p className="text-lg text-gray-600">
                  <span className="font-semibold">Plaquettes arrière :</span> à partir de 79€
                </p>
                <p className="text-lg text-gray-600">
                  <span className="font-semibold">Plaquettes avant + disques :</span> à partir de 189€
                </p>
                <p className="mt-2 text-sm text-gray-500">
                  *Les prix peuvent varier selon le modèle et la qualité des plaquettes
                </p>
              </div>

              <div className="mt-8">
                <Button size="lg" asChild>
                  <Link href="/rendez-vous">Prendre rendez-vous</Link>
                </Button>
              </div>
            </div>

            <div className="space-y-8">
              <div className="relative h-[300px] overflow-hidden rounded-lg">
                <Image
                  src="/placeholder.svg?height=600&width=800&query=brake pad replacement"
                  alt="Remplacement plaquettes de frein"
                  fill
                  className="object-cover"
                />
              </div>

              <Card>
                <CardContent className="p-6">
                  <h3 className="font-montserrat text-lg font-semibold text-navy-blue">
                    Quand remplacer les plaquettes de frein ?
                  </h3>
                  <p className="mt-2 text-gray-600">
                    La durée de vie des plaquettes de frein dépend de plusieurs facteurs : style de conduite, type de
                    véhicule, environnement de conduite, etc. En général :
                  </p>
                  <ul className="mt-4 space-y-2 text-gray-600">
                    <li>• Tous les 30 000 à 50 000 km pour les plaquettes avant</li>
                    <li>• Tous les 50 000 à 80 000 km pour les plaquettes arrière</li>
                    <li>• Plus fréquemment en conduite urbaine ou sportive</li>
                  </ul>
                </CardContent>
              </Card>

              <div className="rounded-lg border p-6">
                <h3 className="font-montserrat text-lg font-semibold text-navy-blue">Signes d'usure à surveiller</h3>
                <ul className="mt-4 space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="mr-2 mt-1 h-5 w-5 text-green-500" />
                    <span>Bruits de grincement ou sifflement lors du freinage</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="mr-2 mt-1 h-5 w-5 text-green-500" />
                    <span>Vibrations dans la pédale de frein ou le volant</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="mr-2 mt-1 h-5 w-5 text-green-500" />
                    <span>Allongement de la distance de freinage</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="mr-2 mt-1 h-5 w-5 text-green-500" />
                    <span>Voyant de frein allumé au tableau de bord</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <AppointmentCTA />
    </div>
  )
}
