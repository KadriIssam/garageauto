import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle } from "lucide-react"
import AppointmentCTA from "@/components/appointment-cta"

export default function VidangePage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-navy-blue py-16 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="font-montserrat text-4xl font-bold md:text-5xl">Vidange et filtres</h1>
            <p className="mt-6 text-lg text-gray-300">
              Maintenez votre moteur en parfait état avec notre service de vidange professionnelle
            </p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-2">
            <div>
              <h2 className="font-montserrat text-2xl font-bold text-navy-blue md:text-3xl">
                Pourquoi faire une vidange régulière ?
              </h2>
              <p className="mt-4 text-lg text-gray-600">
                La vidange est l'opération d'entretien la plus importante pour votre véhicule. Elle permet de :
              </p>
              <ul className="mt-6 space-y-4">
                <li className="flex items-start">
                  <CheckCircle className="mr-2 mt-1 h-5 w-5 text-green-500" />
                  <span>Prolonger la durée de vie de votre moteur</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="mr-2 mt-1 h-5 w-5 text-green-500" />
                  <span>Optimiser les performances et réduire la consommation</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="mr-2 mt-1 h-5 w-5 text-green-500" />
                  <span>Éviter les pannes coûteuses et les réparations importantes</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="mr-2 mt-1 h-5 w-5 text-green-500" />
                  <span>Maintenir la valeur de revente de votre véhicule</span>
                </li>
              </ul>

              <h3 className="mt-10 font-montserrat text-xl font-semibold text-navy-blue">
                Notre service de vidange comprend :
              </h3>
              <ul className="mt-4 space-y-2 text-gray-600">
                <li>• Vidange de l'huile moteur avec huile de qualité adaptée à votre véhicule</li>
                <li>• Remplacement du filtre à huile</li>
                <li>• Vérification et remplacement si nécessaire du filtre à air</li>
                <li>• Vérification et remplacement si nécessaire du filtre à carburant</li>
                <li>• Vérification et remplacement si nécessaire du filtre d'habitacle</li>
                <li>• Contrôle des niveaux (liquide de frein, liquide de refroidissement, etc.)</li>
                <li>• Vérification visuelle des principaux organes mécaniques</li>
                <li>• Remise à zéro du témoin de vidange</li>
              </ul>

              <div className="mt-10">
                <h3 className="font-montserrat text-xl font-semibold text-navy-blue">Tarifs :</h3>
                <p className="mt-2 text-lg text-gray-600">
                  <span className="font-semibold">Vidange standard :</span> à partir de 79€
                </p>
                <p className="text-lg text-gray-600">
                  <span className="font-semibold">Vidange premium :</span> à partir de 119€
                </p>
                <p className="mt-2 text-sm text-gray-500">
                  *Les prix peuvent varier selon le modèle et le type d'huile nécessaire
                </p>
              </div>

              <div className="mt-8">
                <Button size="lg" asChild>
                  <Link href="/rendez-vous">Prendre rendez-vous</Link>
                </Button>
              </div>
            </div>

            <div className="space-y-8">
              <div className="relative h-[300px] overflow-hidden rounded-lg">
                <Image src="/placeholder.svg?key=v0oqh" alt="Service de vidange" fill className="object-cover" />
              </div>

              <Card>
                <CardContent className="p-6">
                  <h3 className="font-montserrat text-lg font-semibold text-navy-blue">
                    Quand faire la vidange de votre véhicule ?
                  </h3>
                  <p className="mt-2 text-gray-600">
                    La fréquence de vidange dépend de plusieurs facteurs : type de véhicule, type de carburant,
                    conditions d'utilisation, etc. En général, nous recommandons :
                  </p>
                  <ul className="mt-4 space-y-2 text-gray-600">
                    <li>• Tous les 10 000 à 15 000 km pour les véhicules essence</li>
                    <li>• Tous les 5 000 à 10 000 km pour les véhicules diesel</li>
                    <li>• Au moins une fois par an, même si vous roulez peu</li>
                  </ul>
                  <p className="mt-4 text-gray-600">
                    Consultez le carnet d'entretien de votre véhicule ou demandez conseil à nos techniciens pour
                    connaître la fréquence idéale pour votre voiture.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <AppointmentCTA />
    </div>
  )
}
