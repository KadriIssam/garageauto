import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { ChevronRight } from "lucide-react"
import AppointmentCTA from "@/components/appointment-cta"

export default function EntretienPage() {
  const services = [
    {
      id: 1,
      title: "Révision complète",
      description: "Contrôle des points de sécurité et maintenance selon préconisations constructeur",
      price: "À partir de 149€",
      image: "/placeholder.svg?key=d4qws",
    },
    {
      id: 2,
      title: "Vidange et filtres",
      description: "Remplacement de l'huile moteur et des filtres (huile, air, carburant, habitacle)",
      price: "À partir de 79€",
      image: "/placeholder.svg?key=wy9m3",
    },
    {
      id: 3,
      title: "Distribution",
      description: "Remplacement de la courroie/chaîne de distribution et pompe à eau",
      price: "À partir de 350€",
      image: "/placeholder.svg?key=wm8zm",
    },
    {
      id: 4,
      title: "Climatisation",
      description: "Recharge, désinfection et entretien du système de climatisation",
      price: "À partir de 89€",
      image: "/placeholder.svg?height=200&width=300&query=car air conditioning service",
    },
  ]

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-navy-blue py-16 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="font-montserrat text-4xl font-bold md:text-5xl">Services d'entretien</h1>
            <p className="mt-6 text-lg text-gray-300">
              Maintenez votre véhicule en parfait état avec nos services d'entretien régulier
            </p>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            {services.map((service) => (
              <Card key={service.id} className="h-full overflow-hidden">
                <div className="relative h-48 w-full">
                  <Image src={service.image || "/placeholder.svg"} alt={service.title} fill className="object-cover" />
                </div>
                <CardContent className="pt-6">
                  <h3 className="mb-2 font-montserrat text-xl font-semibold text-navy-blue">{service.title}</h3>
                  <p className="mb-4 text-gray-600">{service.description}</p>
                  <p className="font-montserrat text-lg font-semibold text-navy-blue">{service.price}</p>
                </CardContent>
                <CardFooter>
                  <Button asChild>
                    <Link href="/rendez-vous">
                      Prendre rendez-vous
                      <ChevronRight className="ml-1 h-4 w-4" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <AppointmentCTA />
    </div>
  )
}
