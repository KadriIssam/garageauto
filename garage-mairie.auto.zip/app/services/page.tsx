import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Wrench, PenToolIcon as Tool, ShieldCheck, Paintbrush, Car, ChevronRight } from "lucide-react"
import AppointmentCTA from "@/components/appointment-cta"

export default function ServicesPage() {
  // Mettre à jour les catégories de services pour correspondre au site original
  const serviceCategories = [
    {
      id: "entretien",
      name: "Entretien",
      icon: <Tool className="h-5 w-5" />,
    },
    {
      id: "mecanique",
      name: "Mécanique",
      icon: <Wrench className="h-5 w-5" />,
    },
    {
      id: "freinage",
      name: "Freinage",
      icon: <ShieldCheck className="h-5 w-5" />,
    },
    {
      id: "carrosserie",
      name: "Carrosserie",
      icon: <Paintbrush className="h-5 w-5" />,
    },
    {
      id: "vehicules",
      name: "Véhicules",
      icon: <Car className="h-5 w-5" />,
    },
  ]

  const services = {
    mecanique: [
      {
        id: 1,
        title: "Réparation moteur",
        description: "Diagnostic et réparation de tous types de moteurs (essence, diesel, hybride)",
        price: "Sur devis",
        image: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 2,
        title: "Système de freinage",
        description: "Remplacement des plaquettes, disques, étriers et liquide de frein",
        price: "À partir de 89€",
        image: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 3,
        title: "Suspension et direction",
        description: "Réparation et remplacement des amortisseurs, rotules et triangles",
        price: "À partir de 120€",
        image: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 4,
        title: "Embrayage et boîte de vitesses",
        description: "Remplacement d'embrayage et réparation de boîte de vitesses",
        price: "Sur devis",
        image: "/placeholder.svg?height=200&width=300",
      },
    ],
    entretien: [
      {
        id: 1,
        title: "Révision complète",
        description: "Contrôle des points de sécurité et maintenance selon préconisations constructeur",
        price: "À partir de 149€",
        image: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 2,
        title: "Vidange et filtres",
        description: "Remplacement de l'huile moteur et des filtres (huile, air, carburant, habitacle)",
        price: "À partir de 79€",
        image: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 3,
        title: "Distribution",
        description: "Remplacement de la courroie/chaîne de distribution et pompe à eau",
        price: "À partir de 350€",
        image: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 4,
        title: "Pneumatiques",
        description: "Montage, équilibrage et permutation de pneumatiques toutes marques",
        price: "À partir de 25€/pneu",
        image: "/placeholder.svg?height=200&width=300",
      },
    ],
    diagnostic: [
      {
        id: 1,
        title: "Diagnostic électronique",
        description: "Lecture et effacement des codes défauts avec matériel professionnel",
        price: "49€",
        image: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 2,
        title: "Diagnostic climatisation",
        description: "Contrôle d'étanchéité et recharge de gaz climatisation",
        price: "À partir de 89€",
        image: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 3,
        title: "Diagnostic pré-contrôle technique",
        description: "Vérification complète avant passage au contrôle technique",
        price: "59€",
        image: "/placeholder.svg?height=200&width=300",
      },
    ],
    carrosserie: [
      {
        id: 1,
        title: "Réparation de carrosserie",
        description: "Réparation de tous types de dommages (bosses, rayures, impacts)",
        price: "Sur devis",
        image: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 2,
        title: "Peinture",
        description: "Mise en peinture partielle ou complète avec cabine professionnelle",
        price: "Sur devis",
        image: "/placeholder.svg?height=200&width=300",
      },
    ],
    vehicules: [
      {
        id: 1,
        title: "Vente de véhicules d'occasion",
        description: "Large choix de véhicules d'occasion contrôlés et garantis",
        price: "Voir catalogue",
        image: "/placeholder.svg?height=200&width=300",
      },
      {
        id: 2,
        title: "Reprise de véhicules",
        description: "Estimation et reprise de votre ancien véhicule",
        price: "Estimation gratuite",
        image: "/placeholder.svg?height=200&width=300",
      },
    ],
  }

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-navy-blue py-16 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="font-montserrat text-4xl font-bold md:text-5xl">Nos services</h1>
            <p className="mt-6 text-lg text-gray-300">
              Des prestations complètes pour l'entretien et la réparation de votre véhicule, réalisées par nos
              mécaniciens qualifiés
            </p>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Tabs defaultValue="entretien" className="w-full">
            <TabsList className="mb-8 flex w-full flex-wrap justify-center gap-2">
              {serviceCategories.map((category) => (
                <TabsTrigger key={category.id} value={category.id} className="flex items-center gap-2">
                  {category.icon}
                  {category.name}
                </TabsTrigger>
              ))}
            </TabsList>

            {Object.entries(services).map(([category, categoryServices]) => (
              <TabsContent key={category} value={category}>
                <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
                  {categoryServices.map((service) => (
                    <Card key={service.id} className="h-full overflow-hidden">
                      <div className="relative h-48 w-full">
                        <Image
                          src={service.image || "/placeholder.svg"}
                          alt={service.title}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <CardContent className="pt-6">
                        <h3 className="mb-2 font-montserrat text-xl font-semibold text-navy-blue">{service.title}</h3>
                        <p className="mb-4 text-gray-600">{service.description}</p>
                        <p className="font-montserrat text-lg font-semibold text-navy-blue">{service.price}</p>
                      </CardContent>
                      <CardFooter>
                        <Button asChild>
                          <Link href="/rendez-vous">
                            Prendre rendez-vous
                            <ChevronRight className="ml-1 h-4 w-4" />
                          </Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </section>

      {/* CTA Section */}
      <AppointmentCTA />
    </div>
  )
}
