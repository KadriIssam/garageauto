import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { ChevronRight } from "lucide-react"
import AppointmentCTA from "@/components/appointment-cta"

export default function MecaniquePage() {
  const services = [
    {
      id: 1,
      title: "Réparation moteur",
      description: "Diagnostic et réparation de tous types de moteurs (essence, diesel, hybride)",
      price: "Sur devis",
      image: "/placeholder.svg?height=200&width=300&query=car engine repair",
    },
    {
      id: 2,
      title: "Suspension et direction",
      description: "Réparation et remplacement des amortisseurs, rotules et triangles",
      price: "À partir de 120€",
      image: "/placeholder.svg?height=200&width=300&query=car suspension repair",
    },
    {
      id: 3,
      title: "Embrayage et boîte de vitesses",
      description: "Remplacement d'embrayage et réparation de boîte de vitesses",
      price: "Sur devis",
      image: "/placeholder.svg?height=200&width=300&query=car clutch replacement",
    },
    {
      id: 4,
      title: "Diagnostic électronique",
      description: "Analyse complète des systèmes électroniques de votre véhicule",
      price: "À partir de 49€",
      image: "/placeholder.svg?height=200&width=300&query=car electronic diagnostic",
    },
  ]

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-navy-blue py-16 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="font-montserrat text-4xl font-bold md:text-5xl">Services de mécanique</h1>
            <p className="mt-6 text-lg text-gray-300">
              Réparations et interventions mécaniques pour toutes marques de véhicules
            </p>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            {services.map((service) => (
              <Card key={service.id} className="h-full overflow-hidden">
                <div className="relative h-48 w-full">
                  <Image src={service.image || "/placeholder.svg"} alt={service.title} fill className="object-cover" />
                </div>
                <CardContent className="pt-6">
                  <h3 className="mb-2 font-montserrat text-xl font-semibold text-navy-blue">{service.title}</h3>
                  <p className="mb-4 text-gray-600">{service.description}</p>
                  <p className="font-montserrat text-lg font-semibold text-navy-blue">{service.price}</p>
                </CardContent>
                <CardFooter>
                  <Button asChild>
                    <Link href="/rendez-vous">
                      Prendre rendez-vous
                      <ChevronRight className="ml-1 h-4 w-4" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <AppointmentCTA />
    </div>
  )
}
