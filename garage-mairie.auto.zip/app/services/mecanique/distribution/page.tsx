import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { AlertTriangle, CheckCircle } from "lucide-react"
import AppointmentCTA from "@/components/appointment-cta"

export default function DistributionPage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-navy-blue py-16 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="font-montserrat text-4xl font-bold md:text-5xl">Distribution</h1>
            <p className="mt-6 text-lg text-gray-300">
              Remplacement de courroie ou chaîne de distribution par des professionnels qualifiés
            </p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-2">
            <div>
              <h2 className="font-montserrat text-2xl font-bold text-navy-blue md:text-3xl">
                La distribution : un élément crucial de votre moteur
              </h2>
              <p className="mt-4 text-lg text-gray-600">
                La distribution est un élément essentiel du moteur qui synchronise le mouvement des soupapes avec celui
                des pistons. Une défaillance de la courroie ou de la chaîne de distribution peut entraîner des dommages
                graves et coûteux pour votre moteur.
              </p>

              <Card className="mt-6 border-amber-300 bg-amber-50">
                <CardContent className="flex items-start p-4">
                  <AlertTriangle className="mr-3 h-6 w-6 flex-shrink-0 text-amber-500" />
                  <div>
                    <h3 className="font-montserrat text-base font-semibold text-amber-800">Attention</h3>
                    <p className="text-amber-700">
                      Une rupture de la courroie de distribution peut causer des dommages irréversibles à votre moteur,
                      nécessitant souvent son remplacement complet. Ne négligez pas cet entretien préventif !
                    </p>
                  </div>
                </CardContent>
              </Card>

              <h3 className="mt-10 font-montserrat text-xl font-semibold text-navy-blue">
                Notre service de remplacement comprend :
              </h3>
              <ul className="mt-4 space-y-2 text-gray-600">
                <li>• Remplacement de la courroie ou chaîne de distribution</li>
                <li>• Remplacement des galets tendeurs et enrouleurs</li>
                <li>• Remplacement de la pompe à eau (recommandé)</li>
                <li>• Vérification du système de refroidissement</li>
                <li>• Contrôle de l'étanchéité du circuit</li>
                <li>• Réglage de la distribution selon les spécifications du constructeur</li>
              </ul>

              <div className="mt-10">
                <h3 className="font-montserrat text-xl font-semibold text-navy-blue">Tarifs :</h3>
                <p className="mt-2 text-lg text-gray-600">
                  <span className="font-semibold">Courroie de distribution :</span> à partir de 350€
                </p>
                <p className="text-lg text-gray-600">
                  <span className="font-semibold">Courroie + pompe à eau :</span> à partir de 450€
                </p>
                <p className="text-lg text-gray-600">
                  <span className="font-semibold">Chaîne de distribution :</span> sur devis
                </p>
                <p className="mt-2 text-sm text-gray-500">
                  *Les prix peuvent varier selon le modèle et la complexité de l'intervention
                </p>
              </div>

              <div className="mt-8">
                <Button size="lg" asChild>
                  <Link href="/rendez-vous">Prendre rendez-vous</Link>
                </Button>
              </div>
            </div>

            <div className="space-y-8">
              <div className="relative h-[300px] overflow-hidden rounded-lg">
                <Image
                  src="/placeholder.svg?height=600&width=800&query=timing belt replacement"
                  alt="Remplacement courroie de distribution"
                  fill
                  className="object-cover"
                />
              </div>

              <Card>
                <CardContent className="p-6">
                  <h3 className="font-montserrat text-lg font-semibold text-navy-blue">
                    Quand remplacer la distribution ?
                  </h3>
                  <p className="mt-2 text-gray-600">
                    La fréquence de remplacement varie selon les constructeurs et les modèles :
                  </p>
                  <ul className="mt-4 space-y-2 text-gray-600">
                    <li>• Courroie de distribution : généralement entre 60 000 et 120 000 km ou tous les 5 à 10 ans</li>
                    <li>
                      • Chaîne de distribution : généralement plus durable, mais nécessite parfois un remplacement entre
                      120 000 et 200 000 km
                    </li>
                  </ul>
                  <p className="mt-4 text-gray-600">
                    Consultez le carnet d'entretien de votre véhicule ou demandez conseil à nos techniciens pour
                    connaître l'intervalle recommandé pour votre voiture.
                  </p>
                </CardContent>
              </Card>

              <div className="rounded-lg border p-6">
                <h3 className="font-montserrat text-lg font-semibold text-navy-blue">Signes d'usure à surveiller</h3>
                <ul className="mt-4 space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="mr-2 mt-1 h-5 w-5 text-green-500" />
                    <span>Bruits anormaux provenant du moteur (claquements, sifflements)</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="mr-2 mt-1 h-5 w-5 text-green-500" />
                    <span>Difficultés au démarrage</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="mr-2 mt-1 h-5 w-5 text-green-500" />
                    <span>Fumée anormale à l'échappement</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="mr-2 mt-1 h-5 w-5 text-green-500" />
                    <span>Perte de puissance du moteur</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <AppointmentCTA />
    </div>
  )
}
