"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Plus, Edit, Trash2, AlertCircle } from "lucide-react"

export default function AdminInventory() {
  const [searchQuery, setSearchQuery] = useState("")

  // Sample data for inventory
  const inventory = [
    {
      id: 1,
      reference: "FH-2345",
      name: "Filtre à huile",
      category: "Filtration",
      compatibility: "Multimarques",
      quantity: 2,
      minQuantity: 5,
      price: 12.5,
    },
    {
      id: 2,
      reference: "PF-1234",
      name: "Plaquettes de frein avant",
      category: "Freinage",
      compatibility: "Renault, Peugeot",
      quantity: 8,
      minQuantity: 4,
      price: 45.9,
    },
    {
      id: 3,
      reference: "BA-7890",
      name: "Batterie 60Ah",
      category: "Électricité",
      compatibility: "Multimarques",
      quantity: 6,
      minQuantity: 3,
      price: 89.9,
    },
    {
      id: 4,
      reference: "HM-5678",
      name: "Huile moteur 5W40 (5L)",
      category: "Lubrifiants",
      compatibility: "Universel",
      quantity: 15,
      minQuantity: 5,
      price: 32.5,
    },
    {
      id: 5,
      reference: "AM-4567",
      name: "Amortisseur avant",
      category: "Suspension",
      compatibility: "Peugeot, Citroën",
      quantity: 4,
      minQuantity: 2,
      price: 78.9,
    },
  ]

  const filteredInventory = inventory.filter((item) => {
    return (
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.reference.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.category.toLowerCase().includes(searchQuery.toLowerCase())
    )
  })

  const getStockStatus = (quantity: number, minQuantity: number) => {
    if (quantity <= 0) {
      return <Badge className="bg-red-500">Rupture</Badge>
    } else if (quantity < minQuantity) {
      return <Badge className="bg-amber-500">Faible</Badge>
    } else {
      return <Badge className="bg-green-500">OK</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Gestion de l'inventaire</CardTitle>
            <CardDescription>Gérez le stock de pièces automobiles</CardDescription>
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Nouvelle pièce
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Ajouter une nouvelle pièce</DialogTitle>
                <DialogDescription>Remplissez les informations de la pièce ci-dessous</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="reference">Référence</Label>
                    <Input id="reference" placeholder="Ex: FH-2345" className="mt-1" />
                  </div>
                  <div>
                    <Label htmlFor="category">Catégorie</Label>
                    <Select>
                      <SelectTrigger id="category" className="mt-1">
                        <SelectValue placeholder="Sélectionner" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="filtration">Filtration</SelectItem>
                        <SelectItem value="freinage">Freinage</SelectItem>
                        <SelectItem value="electricite">Électricité</SelectItem>
                        <SelectItem value="lubrifiants">Lubrifiants</SelectItem>
                        <SelectItem value="suspension">Suspension</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="col-span-2">
                    <Label htmlFor="name">Nom de la pièce</Label>
                    <Input id="name" placeholder="Nom complet de la pièce" className="mt-1" />
                  </div>
                  <div className="col-span-2">
                    <Label htmlFor="compatibility">Compatibilité</Label>
                    <Input id="compatibility" placeholder="Ex: Renault, Peugeot" className="mt-1" />
                  </div>
                  <div>
                    <Label htmlFor="quantity">Quantité</Label>
                    <Input id="quantity" type="number" placeholder="0" className="mt-1" />
                  </div>
                  <div>
                    <Label htmlFor="minQuantity">Quantité minimale</Label>
                    <Input id="minQuantity" type="number" placeholder="0" className="mt-1" />
                  </div>
                  <div>
                    <Label htmlFor="price">Prix unitaire (€)</Label>
                    <Input id="price" type="number" step="0.01" placeholder="0.00" className="mt-1" />
                  </div>
                  <div>
                    <Label htmlFor="location">Emplacement</Label>
                    <Input id="location" placeholder="Ex: Étagère B3" className="mt-1" />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="submit">Ajouter la pièce</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <div className="mb-6 flex items-center space-x-2">
            <Search className="h-5 w-5 text-gray-400" />
            <Input
              placeholder="Rechercher une pièce..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="max-w-sm"
            />
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Référence</TableHead>
                  <TableHead>Nom</TableHead>
                  <TableHead>Catégorie</TableHead>
                  <TableHead>Compatibilité</TableHead>
                  <TableHead>Quantité</TableHead>
                  <TableHead>Prix unitaire</TableHead>
                  <TableHead>Statut</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredInventory.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">{item.reference}</TableCell>
                    <TableCell>{item.name}</TableCell>
                    <TableCell>{item.category}</TableCell>
                    <TableCell>{item.compatibility}</TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        {item.quantity < item.minQuantity && <AlertCircle className="mr-2 h-4 w-4 text-amber-500" />}
                        {item.quantity}
                      </div>
                    </TableCell>
                    <TableCell>{item.price.toFixed(2)} €</TableCell>
                    <TableCell>{getStockStatus(item.quantity, item.minQuantity)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Button variant="ghost" size="icon">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
