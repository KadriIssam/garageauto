"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Plus, Edit, Trash2, User, Building, FileText } from "lucide-react"

export default function AdminClients() {
  const [searchQuery, setSearchQuery] = useState("")

  // Sample data for clients
  const clients = [
    {
      id: 1,
      name: "Sophie Martin",
      email: "sophie.martin@example.com",
      phone: "06 12 34 56 78",
      type: "particulier",
      vehicles: ["Renault Clio (2018)"],
      lastVisit: "02/05/2025",
    },
    {
      id: 2,
      name: "Thomas Dubois",
      email: "thomas.dubois@example.com",
      phone: "06 23 45 67 89",
      type: "particulier",
      vehicles: ["Peugeot 308 (2019)"],
      lastVisit: "28/04/2025",
    },
    {
      id: 3,
      name: "Entreprise Logistique XYZ",
      email: "contact@logistique-xyz.fr",
      phone: "01 23 45 67 89",
      type: "professionnel",
      vehicles: ["Renault Kangoo (2020)", "Citroën Berlingo (2021)", "Peugeot Partner (2019)"],
      lastVisit: "30/04/2025",
    },
    {
      id: 4,
      name: "Marie Leroy",
      email: "marie.leroy@example.com",
      phone: "06 34 56 78 90",
      type: "particulier",
      vehicles: ["Citroën C3 (2020)"],
      lastVisit: "25/04/2025",
    },
    {
      id: 5,
      name: "Jean Dupont",
      email: "jean.dupont@example.com",
      phone: "06 45 67 89 01",
      type: "particulier",
      vehicles: ["Volkswagen Golf (2017)"],
      lastVisit: "01/05/2025",
    },
  ]

  const filteredClients = clients.filter((client) => {
    return (
      client.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      client.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      client.phone.includes(searchQuery)
    )
  })

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Gestion des clients</CardTitle>
            <CardDescription>Consultez et gérez les informations clients</CardDescription>
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Nouveau client
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Ajouter un nouveau client</DialogTitle>
                <DialogDescription>Remplissez les informations du client ci-dessous</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <Tabs defaultValue="particulier" className="w-full">
                  <TabsList className="mb-4 grid w-full grid-cols-2">
                    <TabsTrigger value="particulier">
                      <User className="mr-2 h-4 w-4" />
                      Particulier
                    </TabsTrigger>
                    <TabsTrigger value="professionnel">
                      <Building className="mr-2 h-4 w-4" />
                      Professionnel
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="particulier">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="col-span-2">
                        <Label htmlFor="name">Nom complet</Label>
                        <Input id="name" placeholder="Prénom et nom" className="mt-1" />
                      </div>
                      <div>
                        <Label htmlFor="email">Email</Label>
                        <Input id="email" type="email" placeholder="email@example.com" className="mt-1" />
                      </div>
                      <div>
                        <Label htmlFor="phone">Téléphone</Label>
                        <Input id="phone" placeholder="06 12 34 56 78" className="mt-1" />
                      </div>
                      <div className="col-span-2">
                        <Label htmlFor="address">Adresse</Label>
                        <Input id="address" placeholder="Adresse complète" className="mt-1" />
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="professionnel">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="col-span-2">
                        <Label htmlFor="company">Nom de l'entreprise</Label>
                        <Input id="company" placeholder="Nom de l'entreprise" className="mt-1" />
                      </div>
                      <div>
                        <Label htmlFor="siret">SIRET</Label>
                        <Input id="siret" placeholder="Numéro SIRET" className="mt-1" />
                      </div>
                      <div>
                        <Label htmlFor="tva">Numéro TVA</Label>
                        <Input id="tva" placeholder="Numéro TVA" className="mt-1" />
                      </div>
                      <div>
                        <Label htmlFor="contact">Personne à contacter</Label>
                        <Input id="contact" placeholder="Nom du contact" className="mt-1" />
                      </div>
                      <div>
                        <Label htmlFor="contact-phone">Téléphone contact</Label>
                        <Input id="contact-phone" placeholder="06 12 34 56 78" className="mt-1" />
                      </div>
                      <div>
                        <Label htmlFor="pro-email">Email</Label>
                        <Input id="pro-email" type="email" placeholder="email@example.com" className="mt-1" />
                      </div>
                      <div>
                        <Label htmlFor="pro-phone">Téléphone entreprise</Label>
                        <Input id="pro-phone" placeholder="01 23 45 67 89" className="mt-1" />
                      </div>
                      <div className="col-span-2">
                        <Label htmlFor="pro-address">Adresse</Label>
                        <Input id="pro-address" placeholder="Adresse complète" className="mt-1" />
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
              <DialogFooter>
                <Button type="submit">Ajouter le client</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <div className="mb-6 flex items-center space-x-2">
            <Search className="h-5 w-5 text-gray-400" />
            <Input
              placeholder="Rechercher un client..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="max-w-sm"
            />
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nom</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Véhicules</TableHead>
                  <TableHead>Dernière visite</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredClients.map((client) => (
                  <TableRow key={client.id}>
                    <TableCell className="font-medium">{client.name}</TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span>{client.email}</span>
                        <span className="text-sm text-gray-500">{client.phone}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {client.type === "particulier" ? (
                        <Badge variant="outline" className="border-blue-200 bg-blue-50 text-blue-700">
                          Particulier
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="border-purple-200 bg-purple-50 text-purple-700">
                          Professionnel
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col space-y-1">
                        {client.vehicles.map((vehicle, index) => (
                          <span key={index} className="text-sm">
                            {vehicle}
                          </span>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell>{client.lastVisit}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Button variant="ghost" size="icon">
                          <FileText className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
