"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, Edit, Trash2, Search, Filter } from "lucide-react"
import { format } from "date-fns"
import { fr } from "date-fns/locale"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function AdminAppointments() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  // Sample data for appointments
  const appointments = [
    {
      id: 1,
      client: "Sophie Martin",
      service: "Révision complète",
      vehicle: "Renault Clio",
      date: new Date(2025, 4, 5, 10, 0),
      status: "confirmed",
    },
    {
      id: 2,
      client: "Thomas Dubois",
      service: "Vidange et filtres",
      vehicle: "Peugeot 308",
      date: new Date(2025, 4, 5, 14, 30),
      status: "confirmed",
    },
    {
      id: 3,
      client: "Marie Leroy",
      service: "Diagnostic électronique",
      vehicle: "Citroën C3",
      date: new Date(2025, 4, 6, 9, 0),
      status: "pending",
    },
    {
      id: 4,
      client: "Jean Dupont",
      service: "Remplacement freins",
      vehicle: "Volkswagen Golf",
      date: new Date(2025, 4, 6, 11, 30),
      status: "completed",
    },
    {
      id: 5,
      client: "Entreprise Logistique XYZ",
      service: "Entretien flotte",
      vehicle: "Renault Kangoo",
      date: new Date(2025, 4, 7, 8, 0),
      status: "confirmed",
    },
  ]

  const filteredAppointments = appointments.filter((appointment) => {
    // Filtre par recherche
    const matchesSearch =
      appointment.client.toLowerCase().includes(searchQuery.toLowerCase()) ||
      appointment.vehicle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      appointment.service.toLowerCase().includes(searchQuery.toLowerCase())

    // Filtre par statut
    const matchesStatus = statusFilter === "all" || appointment.status === statusFilter

    return matchesSearch && matchesStatus
  })

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "confirmed":
        return <Badge className="bg-green-500">Confirmé</Badge>
      case "pending":
        return <Badge className="bg-amber-500">En attente</Badge>
      case "completed":
        return <Badge className="bg-blue-500">Terminé</Badge>
      default:
        return <Badge className="bg-gray-500">Inconnu</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Gestion des rendez-vous</CardTitle>
            <CardDescription>Consultez et gérez les rendez-vous clients</CardDescription>
          </div>
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Nouveau rendez-vous
          </Button>
        </CardHeader>
        <CardContent>
          <div className="mb-6 flex flex-col space-y-4 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
            <div className="flex items-center space-x-2">
              <Search className="h-5 w-5 text-gray-400" />
              <Input
                placeholder="Rechercher un client, véhicule..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="max-w-sm"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Filter className="h-5 w-5 text-gray-400" />
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filtrer par statut" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tous les statuts</SelectItem>
                  <SelectItem value="confirmed">Confirmés</SelectItem>
                  <SelectItem value="pending">En attente</SelectItem>
                  <SelectItem value="completed">Terminés</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Client</TableHead>
                  <TableHead>Service</TableHead>
                  <TableHead>Véhicule</TableHead>
                  <TableHead>Date & Heure</TableHead>
                  <TableHead>Statut</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAppointments.length > 0 ? (
                  filteredAppointments.map((appointment) => (
                    <TableRow key={appointment.id}>
                      <TableCell className="font-medium">{appointment.client}</TableCell>
                      <TableCell>{appointment.service}</TableCell>
                      <TableCell>{appointment.vehicle}</TableCell>
                      <TableCell>{format(appointment.date, "dd/MM/yyyy HH:mm", { locale: fr })}</TableCell>
                      <TableCell>{getStatusBadge(appointment.status)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end space-x-2">
                          <Button variant="ghost" size="icon">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="h-24 text-center">
                      Aucun rendez-vous trouvé
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>

          <div className="mt-4 flex justify-end">
            <div className="text-sm text-gray-500">
              {filteredAppointments.length} rendez-vous sur {appointments.length} au total
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Prochains rendez-vous</CardTitle>
          <CardDescription>Rendez-vous à venir pour les 7 prochains jours</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {appointments
              .filter((appointment) => appointment.date > new Date())
              .sort((a, b) => a.date.getTime() - b.date.getTime())
              .slice(0, 5)
              .map((appointment) => (
                <div key={appointment.id} className="flex items-center justify-between rounded-lg border p-4">
                  <div>
                    <p className="font-semibold">{appointment.client}</p>
                    <p className="text-sm text-gray-500">
                      {appointment.service} - {appointment.vehicle}
                    </p>
                    <div className="mt-1 flex items-center">
                      <span className="text-sm text-gray-500">
                        {format(appointment.date, "EEEE d MMMM yyyy 'à' HH:mm", { locale: fr })}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getStatusBadge(appointment.status)}
                    <Button variant="outline" size="sm">
                      Détails
                    </Button>
                  </div>
                </div>
              ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
