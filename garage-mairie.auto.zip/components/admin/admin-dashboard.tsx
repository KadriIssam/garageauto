"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, Car, ShoppingCart, TrendingUp, AlertCircle } from "lucide-react"

export default function AdminDashboard() {
  return (
    <div className="space-y-8">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-gray-500">Rendez-vous aujourd'hui</p>
              <p className="mt-2 text-3xl font-bold">8</p>
            </div>
            <div className="rounded-full bg-blue-100 p-3 text-blue-600">
              <Users className="h-6 w-6" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-gray-500">Clients actifs</p>
              <p className="mt-2 text-3xl font-bold">142</p>
            </div>
            <div className="rounded-full bg-green-100 p-3 text-green-600">
              <Users className="h-6 w-6" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-gray-500">Véhicules en vente</p>
              <p className="mt-2 text-3xl font-bold">6</p>
            </div>
            <div className="rounded-full bg-purple-100 p-3 text-purple-600">
              <Car className="h-6 w-6" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-gray-500">Pièces en stock</p>
              <p className="mt-2 text-3xl font-bold">287</p>
            </div>
            <div className="rounded-full bg-amber-100 p-3 text-amber-600">
              <ShoppingCart className="h-6 w-6" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts (Simplified) */}
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Chiffre d'affaires</CardTitle>
            <CardDescription>Évolution du chiffre d'affaires sur les 6 derniers mois</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] flex items-center justify-center">
              <p className="text-gray-500">Graphique du chiffre d'affaires</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Rendez-vous</CardTitle>
            <CardDescription>Nombre de rendez-vous sur les 6 derniers mois</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] flex items-center justify-center">
              <p className="text-gray-500">Graphique des rendez-vous</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Alerts and Notifications */}
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Alertes</CardTitle>
            <CardDescription>Notifications importantes nécessitant votre attention</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start rounded-lg border p-4">
                <AlertCircle className="mr-3 h-5 w-5 text-red-500" />
                <div>
                  <p className="font-semibold">Stock faible : Filtre à huile réf. FH-2345</p>
                  <p className="text-sm text-gray-500">Quantité restante : 2 (seuil minimum : 5)</p>
                </div>
              </div>
              <div className="flex items-start rounded-lg border p-4">
                <AlertCircle className="mr-3 h-5 w-5 text-amber-500" />
                <div>
                  <p className="font-semibold">Rendez-vous à confirmer</p>
                  <p className="text-sm text-gray-500">3 rendez-vous en attente de confirmation pour demain</p>
                </div>
              </div>
              <div className="flex items-start rounded-lg border p-4">
                <TrendingUp className="mr-3 h-5 w-5 text-green-500" />
                <div>
                  <p className="font-semibold">Hausse des rendez-vous en ligne</p>
                  <p className="text-sm text-gray-500">+15% de rendez-vous pris en ligne ce mois-ci</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Activité récente</CardTitle>
            <CardDescription>Dernières actions effectuées sur la plateforme</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start rounded-lg border p-4">
                <div>
                  <p className="font-semibold">Nouveau rendez-vous</p>
                  <p className="text-sm text-gray-500">Sophie Martin - Révision complète - 10/05/2025</p>
                </div>
              </div>
              <div className="flex items-start rounded-lg border p-4">
                <div>
                  <p className="font-semibold">Facture payée</p>
                  <p className="text-sm text-gray-500">Thomas Dubois - F-2024-156 - 145,00 €</p>
                </div>
              </div>
              <div className="flex items-start rounded-lg border p-4">
                <div>
                  <p className="font-semibold">Nouveau client</p>
                  <p className="text-sm text-gray-500">Marie Leroy - Inscription le 03/05/2025</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
