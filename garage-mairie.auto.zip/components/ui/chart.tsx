"use client"

import type React from "react"

// Composants simplifiés pour éviter les erreurs
export const ChartContainer = ({ className, children }: { className?: string; children: React.ReactNode }) => {
  return <div className={className}>{children}</div>
}

export const Chart = ({ data, children }: { data: any[]; children: React.ReactNode }) => {
  return <div className="w-full h-full flex items-center justify-center">{children}</div>
}

export const ChartTooltip = ({ children }: { children?: React.ReactNode }) => {
  return <>{children}</>
}

export const ChartTooltipContent = () => {
  return null
}

export const ChartLegend = ({ children }: { children: React.ReactNode }) => {
  return <div className="mt-4 flex flex-wrap gap-4 text-sm">{children}</div>
}

export const ChartLegendItem = ({ name, value }: { name: string; value: string }) => {
  return (
    <div className="flex items-center gap-2">
      <div className="h-3 w-3 rounded-full bg-navy-blue" />
      <span className="font-medium">{name}:</span>
      <span>{value}</span>
    </div>
  )
}

export const ChartGrid = () => {
  return null
}

export const ChartXAxis = ({ dataKey }: { dataKey: string }) => {
  return null
}

export const ChartYAxis = ({ tickFormatter }: { tickFormatter?: (value: any) => string }) => {
  return null
}

export const ChartArea = ({ dataKey, fill }: { dataKey: string; fill: string }) => {
  return null
}

export const ChartLine = ({
  dataKey,
  stroke,
  strokeWidth,
}: { dataKey: string; stroke: string; strokeWidth: number }) => {
  return null
}

export const ChartBar = ({ dataKey, fill }: { dataKey: string; fill: string }) => {
  return null
}
