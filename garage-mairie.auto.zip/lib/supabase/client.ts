import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"
import type { Database } from "@/lib/supabase/database.types"

// Créer une instance du client Supabase pour le côté client
export const createClient = () => {
  return createClientComponentClient<Database>()
}
